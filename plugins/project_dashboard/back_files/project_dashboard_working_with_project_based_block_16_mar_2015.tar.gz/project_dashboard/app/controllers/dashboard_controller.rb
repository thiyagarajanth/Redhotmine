class DashboardController < ApplicationController
  helper :issues
  helper :users
  helper :custom_fields
  helper :dashboard

  unloadable
  BLOCKS = { 'issuesassignedtome' => :label_assigned_to_me_issues,
             'issuesreportedbyme' => :label_reported_issues,
             'issueswatched' => :label_watched_issues,
             'news' => :label_news_latest,
             'calendar' => :label_calendar,
             'documents' => :label_document_plural,
             'timelog' => :label_spent_time,
             'overduetasks' => :label_overdue_tasks,
             'unmanageabletasks' => :label_unmanageable_tasks
  }.merge(Redmine::Views::MyPage::Block.additional_blocks).freeze

  DEFAULT_LAYOUT = {  'left' => ['issuesassignedtome'],
                      'right' => ['issuesreportedbyme']
  }.freeze

  def index


  end
  def page
    @user = User.current
    @blocks = @user.pref[:my_page_layout] || DEFAULT_LAYOUT
  end

  def page_layout
    @project= Project.find(params[:project_id])
    @user = User.current
    @project_preference = ProjectUserPreference.project_user_preference(User.current.id,@project.id)
    @blocks = @project_preference[:my_page_layout] || DEFAULT_LAYOUT
    # @blocks = @user.pref[:my_page_layout] || DEFAULT_LAYOUT.dup
    @block_options = []

    BLOCKS.each do |k, v|
        unless @blocks.values.flatten.include?(k)
        @block_options << [l("my.blocks.#{v}", :default => [v, v.to_s.humanize]), k.dasherize]
      end
    end
  end

  def add_block
    @project=Project.find(params[:project_id])
    block = params[:block].to_s.underscore
    if block.present? && BLOCKS.key?(block)
      @project_preference = ProjectUserPreference.project_user_preference(User.current.id,@project.id)
      layout = @project_preference[:my_page_layout] || {}
      # remove if already present in a group
      %w(top left right).each {|f| (layout[f] ||= []).delete block }
      layout['top'].unshift block
      @project_preference.others={:my_page_layout=> layout}
      @project_preference.save
    end
    redirect_to dashboard_page_layout_path(:project_id=>@project.id)
  end

  def remove_block
    @project=Project.find(params[:project_id])
    block = params[:block].to_s.underscore
    @user = User.current
    # remove block in all groups
    if block.present? && BLOCKS.key?(block)
      @project_preference = ProjectUserPreference.project_user_preference(User.current.id,@project.id)
      layout = @project_preference[:my_page_layout] || {}
      # remove if already present in a group
      %w(top left right).each {|f| (layout[f] ||= []).delete block }
      @project_preference.others={:my_page_layout=> layout}
      @project_preference.save
    end
    redirect_to dashboard_page_layout_path(:project_id=>@project.id)

  end
  def order_blocks
    @project=Project.find(params[:project_id])
    @project_preference = ProjectUserPreference.project_user_preference(User.current.id,@project.id)
    group = params[:group]
    @user = User.current
    if group.is_a?(String)
      group_items = (params["blocks"] || []).collect(&:underscore)
      group_items.each {|s| s.sub!(/^block_/, '')}
      if group_items and group_items.is_a? Array
        # layout = @user.pref[:my_page_layout] || {}
        layout = @project_preference[:my_page_layout] || {}
        # remove group blocks if they are presents in other groups
        %w(top left right).each {|f|
          layout[f] = (layout[f] || []) - group_items
        }
        layout[group] = group_items
        @project_preference.others={:my_page_layout=> layout}
        @project_preference.save
      end
    end
    render :nothing => true
  end
  def get_version_id

    render "projects/show"
  end

end
