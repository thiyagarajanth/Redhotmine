class Dashboard < ActiveRecord::Base
  unloadable
end
