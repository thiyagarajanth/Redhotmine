module ProjectsControllerPatch
  BLOCKS = { 'issuesassignedtome' => :label_assigned_to_me_issues,
             'issuesreportedbyme' => :label_reported_issues,
             'issueswatched' => :label_watched_issues,
             'news' => :label_news_latest,
             'calendar' => :label_calendar,
             'documents' => :label_document_plural,
             'timelog' => :label_spent_time,
             'overduetasks' => :label_overdue_tasks,
             'unmanageabletasks' => :label_unmanageable_tasks
  }.merge(Redmine::Views::MyPage::Block.additional_blocks).freeze

  DEFAULT_LAYOUT = {  'left' => ['issuesassignedtome'],
                      'right' => ['issuesreportedbyme']
  }.freeze
  def self.included(base)
    base.class_eval do
      unloadable
      # helper :search
      # helper :dashboard
      # include SearchHelper
      # Insert overrides here, for example:
      def show
        @user = User.current
        @project_preference = ProjectUserPreference.project_user_preference(User.current.id,@project.id)
        @blocks = @project_preference[:my_page_layout] || DEFAULT_LAYOUT
        # try to redirect to the requested menu item
        if params[:jump] && redirect_to_project_menu_item(@project, params[:jump])
          return
        end

        @users_by_role = @project.users_by_role
        @subprojects = @project.children.visible.all
        @news = @project.news.limit(5).includes(:author, :project).reorder("#{News.table_name}.created_on DESC").all
        @trackers = @project.rolled_up_trackers

        cond = @project.project_condition(Setting.display_subprojects_issues?)

        @open_issues_by_tracker = Issue.visible.open.where(cond).group(:tracker).count
        @total_issues_by_tracker = Issue.visible.where(cond).group(:tracker).count

        if User.current.allowed_to?(:view_time_entries, @project)
          @total_hours = TimeEntry.visible.where(cond).sum(:hours).to_f
        end
        @data = [
            ['Firefox',   100.0],
            ['IE',       26.8],

            ['Safari',    8.5],
            ['Opera',     6.2],
            ['Others',   0.7]
        ]

        @key = User.current.rss_key

        respond_to do |format|
          format.html
          format.api
        end
      end



      # def show
      #   @user = User.current
      #   @blocks = @user.pref[:my_page_layout] || DEFAULT_LAYOUT
      #   # try to redirect to the requested menu item
      #   if params[:jump] && redirect_to_project_menu_item(@project, params[:jump])
      #     return
      #       #    end
      #
      #   @users_by_role = @project.users_by_role
      #   @subprojects = @project.children.visible.all
      #   @news = @project.news.limit(5).includes(:author, :project).reorder("#{News.table_name}.created_on DESC").all
      #   @trackers = @project.rolled_up_t        #rackers
      #
      #   cond = @project.project_condition(Setting.display_subprojects_i        #ssues?)
      #
      #   @open_issues_by_tracker = Issue.visible.open.where(cond).group(:tracker).count
      #   @total_issues_by_tracker = Issue.visible.where(cond).group(:tracker        #).count
      #
      #   if User.current.allowed_to?(:view_time_entries, @project)
      #     @total_hours = TimeEntry.visible.where(cond).sum(:hours).to_f
      #   end
      #   @data = [
      #       ['Firefox',   100.0],
      #       ['IE',              # 26.8],
      #
      #       ['Safari',    8.5],
      #       ['Opera',     6.2],
      #       ['Others',   0.7]
      #     #      ]
      #
      #   @key = User.current.        #rss_key
      #
      #   respond_to do |format|
      #     format.html
      #     format.api
      #   end
      #
      #   end
      #   end

      end
      #alias_method_chain :show, :plugin # This tells Redmine to allow me to extend show by letting me call it via "show_without_plugin" above.
      # I can outright override it by just calling it "def show", at which case the original controller's method will be overridden instead of extended.
    end
  end


